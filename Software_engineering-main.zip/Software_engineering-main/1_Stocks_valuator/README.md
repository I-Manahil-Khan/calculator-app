## US trading stocks valuator

App use Finviz API to get stocks list and Finance Yahoo to get their historical data.
Based on dataset it calculates stocks fair value and Margin Of Safety.
It helps to see which stocks are undervalued and worth to deep dive.
