# Others
Public repository with various tools.

1 - US trading stock valuator to find undervalued stocks for personal portfolio.

2 - Program tracks keypress and calculates top keys, typing speed during interval and session (Go & Python versions).
