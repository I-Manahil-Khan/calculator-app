# Keypress tracker in Go & Python languages

Go version can find in folder: /src_go_version

Python version can find in folder: /src_python_version